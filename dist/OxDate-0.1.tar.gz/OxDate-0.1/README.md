# OxDate
Tools for Oxford Term Dates

## Dependency

Make sure you have Python 3 installed. Enter `python --version` in your terminal to check.

```bash
$ python --version
3.x.x
```

Here is a guide on how to install Python 3: https://realpython.com/installing-python

## Install